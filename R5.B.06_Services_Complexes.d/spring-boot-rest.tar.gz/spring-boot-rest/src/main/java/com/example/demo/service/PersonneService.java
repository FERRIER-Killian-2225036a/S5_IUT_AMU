package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.model.Personne;

@Service
public class PersonneService implements IPersonneService {

	private List<Personne> personnes;

	public PersonneService() {
		var personne1 = Personne.builder().id(1).nom("Wich").prenom("John").age(55).build();
		var personne2 = Personne.builder().id(2).nom("Logan").prenom("Paul").age(55).build();
		var personne3 = Personne.builder().id(3).nom("Slim").prenom("Shaddy").age(55).build();
		var liste = List.of(personne1, personne2, personne3);
		personnes = new ArrayList<Personne>(liste);
	}

	@Override
	public List<Personne> findAll() {
		return personnes;
	}

	@Override
	public Personne findById(Integer id) {
		//return personnes.stream().filter(e -> e.getId() == id).findFirst().orElse(null);
		for (int i = 0; i < personnes.size(); i++) {
			if (personnes.get(i).getId().equals(id)) {
				return personnes.get(i);
			}
		}
		return null;
	}

	@Override
	public Personne save(Personne p) {
		personnes.add(p);
		return p;
	}

	@Override
	public Personne update(Personne p) {
		for (int i = 0; i < personnes.size(); i++) {
			if (personnes.get(i).getId().equals(p.getId())) {
				personnes.set(i, p);
				return p;
			}
		}
		return null;
	}

	@Override
	public boolean deleteById(Integer id) {
		return personnes.remove(findById(id));
	}

}
