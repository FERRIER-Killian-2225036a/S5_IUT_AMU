package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.exception.PersonneException;
import com.example.demo.model.Personne;
import com.example.demo.service.IPersonneService;

//@Controller
@RestController
@RequestMapping("/personnes")
public class PersonneController {
	@Autowired
	private IPersonneService personneService;

//	@ResponseBody
	@GetMapping
	public List<Personne> getPersonnes() {
		return personneService.findAll();
	}
//	@ResponseBody
	@GetMapping("/{id}")
	public Personne getPersonne(@PathVariable Integer id) {
		var p = personneService.findById(id);
		if (p == null) { throw new PersonneException(); }
		return p;
	}
//	@ResponseBody
	@DeleteMapping("/{id}")
	public ResponseEntity<Boolean> delPersonne(@PathVariable Integer id) {
		var resultat = personneService.deleteById(id);
		//if (p == false) { throw new PersonneException(); }
		if (!resultat) {
			return new ResponseEntity<Boolean>(false, HttpStatus.NOT_FOUND);
		} 
		return new ResponseEntity<Boolean>(true, HttpStatus.NO_CONTENT);
	}
//	@ResponseBody
	@PostMapping
	@ResponseStatus(HttpStatus.CREATED)
	public Personne addPersonne(@RequestBody Personne p) {
		return personneService.save(p);
	}

//	@ResponseBody
	@PutMapping("/{id}")
	public ResponseEntity<Boolean> updatePersonne(@PathVariable Integer id, @RequestBody Personne p) {
		if (id != p.getId()) {
			return new ResponseEntity<Boolean>(false, HttpStatus.BAD_REQUEST);
		}
		var resultat = personneService.update(p);
		if (resultat==null) {
			return new ResponseEntity<Boolean>(false, HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<Boolean>(true, HttpStatus.ACCEPTED); 
	}
}
