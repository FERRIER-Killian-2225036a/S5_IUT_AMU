package com.example.demo.service;

import java.util.List;

import com.example.demo.model.Personne;

public interface IPersonneService {
	public List<Personne> findAll();

	public Personne findById(Integer id);

	public Personne save(Personne p);

	public Personne update(Personne p);

	public boolean deleteById(Integer id);
}
