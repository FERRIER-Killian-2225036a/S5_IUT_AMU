package com.example.dal;

public interface PersonneRepository {

}
